export default class Monster {
  health: number;
  difficultyLevel: number;
  // Other attributes

  constructor(difficultyLevel: number = 1) {
    this.difficultyLevel = difficultyLevel;
    this.health = 50 * difficultyLevel; // Increase health based on difficulty
    // Initialize other attributes
  }

  isDefeated(): boolean {
    return this.health <= 0;
  }

  // Methods for monster behavior
}
