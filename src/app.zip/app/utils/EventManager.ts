import GameState from './GameState';
import Monster from './Monster';
import { allSpells } from './Spell';

export default class EventManager {
  static triggerEvent(gameState: GameState): GameState {
    // Ensure startNewTurn is called only once
    gameState.startNewTurn();

    const randomValue = Math.random() * 100;

    if (randomValue < 40) {
      // 40% chance for a Monster encounter
      this.monsterEncounter(gameState);
    } else if (randomValue < 50) {
      // 10% chance for a Spell selection
      this.spellSelection(gameState);
    } else {
      // 50% chance for a Random Event
      this.randomEvent(gameState);
    }

    // Return the updated game state
    return gameState;
  }

  static randomEvent(gameState: GameState) {
    const events = [
      { message: "You find a shiny coin on the ground.", type: "good", affects: "XP", value: Math.floor(Math.random() * 10) + 1 },
      { message: "A gentle breeze refreshes you.", type: "good", affects: "HP", value: Math.floor(Math.random() * 5) + 1 },
      { message: "You hear distant laughter.", type: "neutral", affects: "none", value: 0 },
      { message: "A bird sings a beautiful song.", type: "good", affects: "XP", value: Math.floor(Math.random() * 5) + 1 },
      { message: "You feel a sudden chill.", type: "bad", affects: "HP", value: -(Math.floor(Math.random() * 5) + 1) },
      { message: "You trip over a root and fall.", type: "bad", affects: "HP", value: -(Math.floor(Math.random() * 10) + 1) },
      { message: "You find a hidden stash of supplies.", type: "good", affects: "XP", value: Math.floor(Math.random() * 15) + 5 },
      { message: "A sudden storm drenches you.", type: "bad", affects: "HP", value: -(Math.floor(Math.random() * 3) + 1) }
    ];

    const randomEvent = events[Math.floor(Math.random() * events.length)];
    let messageAddition = '';

    if (randomEvent.affects === "XP") {
      gameState.player.gainXP(randomEvent.value);
      messageAddition = `You gain ${randomEvent.value} XP.`;
    } else if (randomEvent.affects === "HP") {
      gameState.player.health += randomEvent.value;
      messageAddition = `Your health changes by ${randomEvent.value}.`;
    }

    gameState.addLogEntry(`${randomEvent.message} ${messageAddition}`);
  }

  static monsterEncounter(gameState: GameState) {
    const difficultyLevel = Math.floor(gameState.gameLog.length / 10) + 1; // Increase difficulty over time
    const monster = new Monster(difficultyLevel);
    gameState.addLogEntry(`A wild ${monster.constructor.name} appears with ${monster.health} HP!`);
    gameState.combat(monster);
  }

  static spellSelection(gameState: GameState) {
    // Pick a random spell from the pool
    const randomSpell = allSpells[Math.floor(Math.random() * allSpells.length)];
    const spellIndex = gameState.player.spells.indexOf(randomSpell.name);

    if (spellIndex !== -1) {
      // If the spell is already learned, append a "+"
      gameState.player.spells[spellIndex] += "+";
    } else {
      // If the spell is not learned, add it to the player's spells
      gameState.player.spells.push(randomSpell.name);
      if (!gameState.unlockedSpells.includes(randomSpell.name)) {
        gameState.unlockedSpells.push(randomSpell.name);
        gameState.saveUnlockedSpells();
      }
    }

    gameState.addLogEntry(`You have practiced a spell: ${randomSpell.name}.`);
  }

  static narrativeEvent(gameState: GameState) {
    if (gameState.gameLog.length > 20 && !gameState.gameLog.some(turn => turn.includes('A mysterious figure appears...'))) {
      gameState.addLogEntry('A mysterious figure appears...');
    }
  }

  // Additional event methods can be added here
}
