export default class Player {
  health: number;
  spells: string[];
  xp: number;
  mana: number;

  constructor() {
    this.health = 100;
    this.spells = [];
    this.xp = 0;
    this.mana = 0;
  }

  gainXP(amount: number) {
    this.xp += amount;
  }

  gainMana(amount: number) {
    this.mana += amount;
  }

  // Methods to manage player state
}
