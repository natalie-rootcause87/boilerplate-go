import Player from "./Player";

export default class Spell {
  name: string;
  description: string;
  power: number;
  effect: (target: any) => void;
  targetType: 'player' | 'monster';
  manaCost: number;

  constructor(name: string, description: string, power: number, effect: (target: any) => void, targetType: 'player' | 'monster', manaCost: number) {
    this.name = name;
    this.description = description;
    this.power = power;
    this.effect = effect;
    this.targetType = targetType;
    this.manaCost = manaCost;
  }

  applyEffect(target: any, player: Player) {
    if (player.mana >= this.manaCost) {
      player.mana -= this.manaCost;
      this.effect(target);
    } else {
      console.log(`Not enough mana to cast ${this.name}.`);
    }
  }
}

// Example global table of spells
export const allSpells = [
  new Spell(
    'Fireball',
    'A fiery explosion that burns the target.',
    30,
    (target) => {
      target.health -= 30;
      console.log(`${target.name} is hit by a fireball!`);
    },
    'monster',
    10
  ),
  new Spell(
    'Healing Light',
    'A warm light that heals the target.',
    20,
    (target) => {
      if (target instanceof Player) {
        target.health += 20;
        console.log(`Player is healed by a warm light!`);
      } else {
        console.log(`Healing Light has no effect on ${target.name}.`);
      }
    },
    'player',
    5
  ),
  // Add more spells as needed
];
