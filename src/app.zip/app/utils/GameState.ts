import Player from './Player';
import Monster from './Monster';
import { allSpells } from './Spell';

export interface PartialGameState {
  player: Player;
  gameLog: string[][];
  isGameOver: boolean;
  unlockedSpells: string[];
}

export default class GameState {
  player!: Player;
  gameLog: string[][];
  isGameOver: boolean;
  unlockedSpells: string[];

  constructor() {
    this.loadPlayerState();
    this.gameLog = this.loadGameLog();
    this.isGameOver = false;
    this.unlockedSpells = this.loadUnlockedSpells();
    this.initializePlayerSpells();
  }

  loadUnlockedSpells(): string[] {
    if (typeof window !== 'undefined') {
      const spells = localStorage.getItem('unlockedSpells');
      return spells ? JSON.parse(spells) : [];
    }
    return [];
  }

  saveUnlockedSpells() {
    if (typeof window !== 'undefined') {
      localStorage.setItem('unlockedSpells', JSON.stringify(this.unlockedSpells));
    }
  }

  loadGameLog(): string[][] {
    if (typeof window !== 'undefined') {
      const log = localStorage.getItem('gameLog');
      return log ? JSON.parse(log) : [[]]; // Initialize with an empty array for the first turn
    }
    return [[]];
  }

  saveGameLog() {
    if (typeof window !== 'undefined') {
      localStorage.setItem('gameLog', JSON.stringify(this.gameLog));
    }
  }

  initializePlayerSpells() {
    if (this.unlockedSpells.length > 0) {
      const randomSpell = this.unlockedSpells[Math.floor(Math.random() * this.unlockedSpells.length)];
      this.player.spells.push(randomSpell);
    }
  }

  addLogEntry(entry: string) {
    if (this.gameLog.length === 0) {
      this.gameLog.push([]); // Ensure there's at least one turn
    }
    this.gameLog[this.gameLog.length - 1].push(entry);
    this.saveGameLog();
  }

  startGame() {
    if (this.gameLog.length === 0) {
      this.gameLog.push([]); // Initialize the game log with the first turn
    }
    this.saveGameLog();
  }

  resetGame() {
    this.player = new Player();
    this.gameLog = []; // Reset the game log without initializing a turn
    this.isGameOver = false;
    this.unlockedSpells = []; // Reset unlocked spells
    this.initializePlayerSpells();
    
    // Clear localStorage entries
    if (typeof window !== 'undefined') {
      localStorage.removeItem('gameLog');
      localStorage.removeItem('unlockedSpells');
      localStorage.removeItem('playerState');
    }
    
    this.saveGameLog(); // Save the cleared log
    this.saveUnlockedSpells(); // Save the cleared spells
    this.savePlayerState(); // Save the new player state
  }

  // Method to handle combat
  combat(monster: Monster) {
    let turnCount = 0; // Initialize a turn counter
    const maxTurns = 100; // Define a maximum number of turns to prevent infinite loops

    while (!monster.isDefeated() && this.player.health > 0 && turnCount < maxTurns) {
      turnCount++; // Increment the turn counter
      console.log('turnCount', turnCount);
      if (this.player.spells.length > 0) {
        const randomSpellName = this.player.spells[Math.floor(Math.random() * this.player.spells.length)];
        const spell = allSpells.find(s => s.name === randomSpellName);

        if (spell) {
          spell.applyEffect(monster, this.player); // Pass player to applyEffect
          this.addLogEntry(`Player casts ${spell.name} on ${monster.constructor.name}. Monster HP: ${monster.health}`);
        }
      }
      
      // Use fists if no spells are available or after a spell is used
      const fistDamage = 10; // Define the damage dealt by fists
      monster.health -= fistDamage;
      this.player.gainMana(5); // Gain mana when hitting with fists
      this.addLogEntry(`Player uses fists on ${monster.constructor.name}. Monster HP: ${monster.health}. Player gains 5 mana.`);

      // Check if the monster is defeated
      if (monster.isDefeated()) {
        const xpGained = monster.difficultyLevel * 10; // Calculate XP gained
        this.player.gainXP(xpGained); // Grant XP based on difficulty
        this.addLogEntry(`${monster.constructor.name} has been defeated! Player gains ${xpGained} XP.`);
        return;
      }

      // Monster's return strike
      const monsterDamage = Math.floor(Math.random() * 10) + 1; // Random damage between 1 and 10
      this.player.health -= monsterDamage;
      this.addLogEntry(`${monster.constructor.name} strikes back for ${monsterDamage} damage.`);

      // Check if the player is dead
      if (this.player.health <= 0) {
        this.isGameOver = true;
        this.addLogEntry('Player has been defeated. Game over.');
      }
    }

    if (turnCount >= maxTurns) {
      this.addLogEntry('Combat ended due to reaching the maximum number of turns.');
    }
  }

  static fromPartial(partial: PartialGameState): GameState {
    const newState = new GameState();
    newState.player = partial.player;
    newState.gameLog = partial.gameLog;
    newState.isGameOver = partial.isGameOver;
    newState.unlockedSpells = partial.unlockedSpells;
    return newState;
  }

  // Additional methods to manage game state

  savePlayerState() {
    if (typeof window !== 'undefined') {
      localStorage.setItem('playerState', JSON.stringify(this.player));
    }
  }

  loadPlayerState() {
    if (typeof window !== 'undefined') {
      const playerData = localStorage.getItem('playerState');
      if (playerData) {
        this.player = JSON.parse(playerData);
      } else {
        this.player = new Player();
      }
    }
  }

  startNewTurn() {
    this.gameLog.push([]); // Start a new turn by adding a new array for log entries
    this.saveGameLog(); // Save the updated game log
  }
}
