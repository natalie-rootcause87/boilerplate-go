import React, { useState, useEffect, useRef } from 'react';
import GameState, { PartialGameState } from '../utils/GameState';
import EventManager from '../utils/EventManager';
import Spell, { allSpells } from '../utils/Spell';

export default function Game() {
  const [gameState, setGameState] = useState<GameState | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const actionInProgress = useRef(false);
  const [gameStarted, setGameStarted] = useState(false);
  const [isEntryModalOpen, setIsEntryModalOpen] = useState(false);
  const [currentEntries, setCurrentEntries] = useState<string[]>([]);
  const [renderTrigger, setRenderTrigger] = useState(0);
  const [selectedSpell, setSelectedSpell] = useState<Spell | null>(null);

  useEffect(() => {
    const newGameState = new GameState();
    if (newGameState.unlockedSpells.length > 0) {
      const randomSpell = newGameState.unlockedSpells[Math.floor(Math.random() * newGameState.unlockedSpells.length)];
      newGameState.player.spells.push(randomSpell);
    }
    console.log('Initial GameState:', newGameState);
    setGameState(newGameState);
  }, []);

  const getUpdatedGameState = (prev: GameState | null) => {
    if (!prev || prev.isGameOver) {
      console.log('Game is over, no action taken');
      actionInProgress.current = false;
      return prev;
    }
    console.log('Triggering event for a new turn');
    const updatedState = EventManager.triggerEvent(prev) as GameState | PartialGameState;
    console.log('Updated GameState:', updatedState.gameLog.length, updatedState);
    if (updatedState instanceof GameState) {
      actionInProgress.current = false;
      return updatedState;
    } else {
      const newState = GameState.fromPartial(updatedState);
      actionInProgress.current = false;
      return newState;
    }
  };

  const handleAction = () => {
    if (actionInProgress.current) return;
    actionInProgress.current = true;

    if (!gameState) {
      actionInProgress.current = false;
      return;
    }

    if (!gameStarted) {
      gameState.resetGame();
      setGameStarted(true);
    }

    const updatedGameState = getUpdatedGameState(gameState);

    console.log('Continue button clicked');
    setGameState(updatedGameState);
    setRenderTrigger(prev => prev + 1);

    // Check for combat entry and open modal automatically
    const lastTurnEntries = updatedGameState?.gameLog[updatedGameState.gameLog.length - 1];
    if (Array.isArray(lastTurnEntries) && lastTurnEntries.some(entry => entry.includes('A wild'))) {
      setCurrentEntries([lastTurnEntries[0]]); // Set the first entry immediately
      setIsEntryModalOpen(true);

      // Show remaining entries with a 1-second delay
      let index = 1; // Start from the second entry
      const intervalId = setInterval(() => {
        if (index < lastTurnEntries.length) {
          setCurrentEntries(prevEntries => [...prevEntries, lastTurnEntries[index]]);
          index++;
        } else {
          clearInterval(intervalId);
        }
      }, 1000);
    }
  };

  const handleRestart = () => {
    console.log('Game restarted');
    const newGameState = new GameState();
    newGameState.resetGame();
    if (newGameState.unlockedSpells.length > 0) {
      const randomSpell = newGameState.unlockedSpells[Math.floor(Math.random() * newGameState.unlockedSpells.length)];
      newGameState.player.spells.push(randomSpell);
    }
    setGameState(newGameState);
    setGameStarted(false);
  };

  const toggleModal = () => {
    setIsModalOpen(!isModalOpen);
  };

  const getAnimationClass = (entry: string) => {
    if (entry.includes('A wild')) return 'monster-encounter';
    if (entry.includes('You have practiced a spell')) return 'spell-selection';
    if (entry.includes('Nothing happens')) return 'nothing-happens';
    return '';
  };

  const handleEntryClick = (entries: string[]) => {
    setCurrentEntries(entries);
    setIsEntryModalOpen(true);
  };

  const handleSpellClick = (spellName: string) => {
    const spell = allSpells.find(s => s.name === spellName);
    setSelectedSpell(spell || null);
  };

  if (!gameState) {
    return <div>Loading...</div>;
  }

  return (
    <div className="w-full h-full bg-gradient-to-b from-green-700 to-green-900 flex flex-col items-center text-white">
      {/* Header / Title */}
      <header className="w-full py-6 text-center shadow-lg bg-green-800/70">
        <h1 className="text-3xl font-extrabold tracking-wide uppercase">
          Boilerplate Go
        </h1>
      </header>

      {/* Main Container */}
      <main className="flex-grow max-h-[calc(100%-84px)] w-full max-w-5xl flex flex-col items-center space-y-6 md:space-y-0">
        {/* Player & Game Info */}
        <section className="w-full max-h-full py-4 flex flex-col md:flex-row md:space-x-6 space-y-6 md:space-y-0">
          {/* Player Stats Card */}
          <div className="flex-1 bg-green-800/50 shadow-md rounded-lg p-6">
            <h2 className="text-2xl font-bold mb-4 text-center">Player Stats</h2>
            <div className="flex flex-col items-center space-y-4">
              <div className="text-lg">
                <span className="font-semibold">HP:</span> {gameState.player.health}
              </div>
              <div className="text-lg">
                <span className="font-semibold">XP:</span> {gameState.player.xp}
              </div>
              <div className="text-lg">
                <span className="font-semibold">Mana:</span> {gameState.player.mana}
              </div>
              <div className="text-lg">
                <span className="font-semibold">Spells:</span>{" "}
                {gameState.player.spells.length > 0
                  ? gameState.player.spells.map(spell => (
                    <button
                      key={spell}
                      onClick={() => handleSpellClick(spell)}
                      className="cursor-pointer underline"
                    >
                      {spell}
                    </button>
                  ))
                  : "None"}
              </div>
            </div>
          </div>

          {/* Game Log Card */}
          {gameStarted && (
            <div className="flex-1 bg-green-800/50 shadow-md rounded-lg p-6 flex flex-col max-h-full">
            <h2 className="text-2xl font-bold mb-4 text-center">Game Log</h2>
            <ul className="flex-grow overflow-y-auto space-y-2 px-4 py-2">
              {gameState.gameLog.length && gameState.gameLog.slice(Math.max(gameState.gameLog.length - 3, 0)).map((turnEntries, turnIndex) => (
                <li key={turnIndex} className="mb-4">
                  <div className="font-bold">
                    Turn {gameState.gameLog.length > 3 ? gameState.gameLog.length - (2 - turnIndex) : turnIndex + 1}
                  </div>
                  <ul>
                    {Array.isArray(turnEntries) ? (
                      <li
                        key={0}
                        className={`text-sm bg-green-900/50 p-3 rounded ${turnIndex === 2 ? 'highlight' : ''} ${turnIndex === 2 ? getAnimationClass(turnEntries[0]) : ''}`}
                      >
                        {turnEntries[turnEntries.length - 1]}
                        {turnEntries.length > 1 && (
                          <button
                            onClick={() => handleEntryClick(turnEntries)}
                            className="ml-2 text-blue-500"
                          >
                            ▼
                          </button>
                        )}
                      </li>
                    ) : (
                      <li className="text-sm bg-red-900/50 p-3 rounded">
                        {turnEntries}
                      </li>
                    )}
                  </ul>
                </li>
              ))}
            </ul>
            {gameState.gameLog.length > 3 && (
              <button
                onClick={toggleModal}
                className="mt-4 bg-blue-500 hover:bg-blue-600 transition-colors text-white font-bold py-2 px-4 rounded"
              >
                View Full Log
              </button>
            )}
          </div>
          )}
        </section>

        {/* Action / Restart Buttons */}
        {gameState.isGameOver ? (
          <section className="w-full max-w-md bg-red-700/50 rounded-lg shadow-md p-6 text-center">
            <h2 className="text-xl font-extrabold text-red-200 mb-6">Game Over</h2>
            <button
              onClick={handleRestart}
              className="bg-red-500 hover:bg-red-600 transition-colors text-white font-bold py-3 px-6 rounded"
            >
              Restart Game
            </button>
          </section>
        ) : (
          <button
            onClick={handleAction}
            className="bg-blue-600 hover:bg-blue-700 transition-colors text-white font-semibold py-3 px-8 rounded shadow-md"
          >
            {gameStarted ? 'Continue' : 'Start Game'}
          </button>
        )}
      </main>

      {/* Full Log Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
          <div className="bg-white text-black p-6 rounded-lg shadow-lg max-w-lg w-full">
            <h2 className="text-xl font-bold mb-4">Full Game Log</h2>
            <ul className="overflow-y-auto max-h-96 space-y-2">
              {gameState.gameLog.map((turnEntries, turnIndex) => (
                <li key={turnIndex} className="mb-4">
                  <div className="font-bold">Turn {turnIndex + 1}</div>
                  <ul>
                    {Array.isArray(turnEntries) ? turnEntries.map((entry, entryIndex) => (
                      <li key={entryIndex} className="text-sm bg-gray-200 p-3 rounded">
                        {entry}
                      </li>
                    )) : (
                      <li className="text-sm bg-gray-200 p-3 rounded">
                        {turnEntries}
                      </li>
                    )}
                  </ul>
                </li>
              ))}
            </ul>
            <button
              onClick={toggleModal}
              className="mt-4 bg-red-500 hover:bg-red-600 transition-colors text-white font-bold py-2 px-4 rounded"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Entry Modal */}
      {isEntryModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
          <div className="bg-white text-black p-6 rounded-lg shadow-lg max-w-lg w-full">
            <h2 className="text-xl font-bold mb-4">Combat Encounter</h2>
            <ul className="overflow-y-auto max-h-96 space-y-2">
              {currentEntries.map((entry, index) => (
                <li key={index} className="text-sm bg-gray-200 p-3 rounded">
                  {entry}
                </li>
              ))}
            </ul>
            <button
              onClick={() => setIsEntryModalOpen(false)}
              className="mt-4 bg-red-500 hover:bg-red-600 transition-colors text-white font-bold py-2 px-4 rounded"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Spell Details Modal */}
      {selectedSpell && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
          <div className="bg-white text-black p-6 rounded-lg shadow-lg max-w-md w-full">
            <h2 className="text-xl font-bold mb-4">{selectedSpell.name}</h2>
            <p><strong>Description:</strong> {selectedSpell.description}</p>
            <p><strong>Power:</strong> {selectedSpell.power}</p>
            <p><strong>Mana Cost:</strong> {selectedSpell.manaCost}</p>
            <button
              onClick={() => setSelectedSpell(null)}
              className="mt-4 bg-red-500 hover:bg-red-600 transition-colors text-white font-bold py-2 px-4 rounded"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
